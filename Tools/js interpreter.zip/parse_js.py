import esprima
import jsbeautifier
import json
import sys
import os 
import re


#=================================== take note of these two "variableDeclaration" and "AssignmentExpression"

def write_to_file(filePath, content):
	with open(filePath, 'wb') as f:
		f.write(bytes(content, 'utf-8'))


def beautify_js(content):
	opts = jsbeautifier.default_options()
	opts.indent_size = 2
	opts.space_in_empty_paren = True
	return jsbeautifier.beautify(content, opts)

def convert_nodeObjects_to_dict(obj):
	t_list = []
	for x in str(obj).split('\n'):
		x=x.lstrip().rstrip()
		if not x.startswith("[") and not x.startswith("]") and not x.startswith("{") and not x.startswith("}"):
			alt = x[:x.find(":")]
			x = f"\"{alt}\""+x[x.find(":"):] 
		t_list.append(x)
	d_str = ''.join(t_list)
	return eval(d_str)

def extract_partial_from_nested_dict(ndict, match):
	try:

		output = []
		if type(ndict) is dict:			
			for k in ndict.keys():		
				if (type(match) is dict) and k == list(match.keys())[0] and ndict[k] == match[list(match.keys())[0]]:				
					output.append( ndict )
				output.extend(extract_partial_from_nested_dict(ndict[k], match))

		elif type(ndict) is list:
			for x in ndict:
				output.extend(extract_partial_from_nested_dict(x, match)) 

		return output
		         
	except Exception as e:
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
		ad = ("ErrorType: "+str(exc_type)+"  in File: "+str(fname)+" Line:"+str(exc_tb.tb_lineno))                       
		print(f"\n\n___________________________Error:   at extract_partial_from_nested_dict: {e} {ad}")                    
		return None

def search_in_nested_dict(obj, match):

	output = ""
	try:
		if type(obj) is dict:
			output += "{"
			for k in obj.keys():		
				#if (type(match) is dict) and k == list(match.keys())[0] and obj[k] == match[list(match.keys())[0]]:				
				#	#output.append( {k:obj[k]} )
				#	output[k] = obj[k]
				output +=  k + ":"
				output += dive_dict_search(obj[k], match)	
			output += "},"

		elif type(obj) is list:
			output += "[" 
			for x in obj:
				output += (dive_dict_search(x, match)) 
			output += "]," 

		else:
			if obj == match[list(match.keys())[0]]:
				output +=  obj+","
			else:
				output +=  "skip,"


		return output
		         

	except Exception as e:
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
		ad = ("ErrorType: "+str(exc_type)+"  in File: "+str(fname)+" Line:"+str(exc_tb.tb_lineno))                       
		print(f"\n\n___________________________Error:   at search_in_nested_dict: {e} {ad}")                    
		return None    	    

def read_js_file_content(filePath):
	try:
		js_content = ""
		with open(filePath, "r") as f:
			js_lines = f.readlines()
			js_content = "".join(js_lines)
		return js_content
	except Exception as e:
		print(f"\n______________________________ Error at read_js_file_content: e={e}")
		return None

def js_parser(raw_content):
	return esprima.parseScript(raw_content)

def find_functions_in_js_script(js_raw_content):
	js_parsed = js_parser(js_raw_content)
	funcitonDec_nodes = [x for x in js_parsed.body if (type(x) is esprima.nodes.FunctionDeclaration)]
	return [{"function_name": x.id.name, "arguments": [j.name for j in x.params] , "function_body": x.body} for x in funcitonDec_nodes]


def find_xhr_open_location(func):

	xhr_obj = "xhttp1"
	http_method = ""
	url_var = ""

	xhr_location_list = []


	expr_list = extract_partial_from_nested_dict(func["body"], {"type": "ExpressionStatement"})

	for ex in expr_list:

		call_expr = extract_partial_from_nested_dict(ex["expression"], {"type":"CallExpression"})

		if len(call_expr)>0 and "callee" in ex["expression"].keys():

			calle = ex["expression"]["callee"]

			if len(extract_partial_from_nested_dict(calle, {"type":"MemberExpression"}))>0 and "object" in calle.keys() and "property" in calle.keys():

				#if calle["object"]["name"] == xhr_obj  and calle["property"]["name"] == "open":
				if calle["property"]["name"] == "open":
					http_method = call_expr[0]["arguments"][0]
					url_var = call_expr[0]["arguments"][1]
					xhr_location_list.append({"url_argument": url_var, "method":http_method}) 

	return xhr_location_list

def find_all_xhr_variable_in_function_body(func):

	xhr_var_names = []

	search1 = {"type":"VariableDeclaration"}
	search2 = {"name":"XMLHttpRequest"}

	# search for variable declarations
	var_decl_list = extract_partial_from_nested_dict(func["body"], search1)
	for var in var_decl_list:

		# search for XHR
		tr = extract_partial_from_nested_dict(var, search2)
		if tr:
			varName = list(var["declarations"])[0]["id"]["name"]
			#tmp = {"function_name":func["id"]["name"], "function_arguments":[ar["name"] for ar in func["params"]], "xhr_var_name":varName}
			tmp = varName
			xhr_var_names.append(tmp)

	return xhr_var_names

def find_all_assignments_in_function_body(func):

	output = []

	search3 = {"type":"AssignmentExpression"}

	# search for variable Assignments
	var_asign_list = extract_partial_from_nested_dict(func["body"], search3)

	tmp = {"function_name":func["id"]["name"], "var_asign_list":[]}


	if var_asign_list:
	

		#[tmp["var_asign_list"].append(v["left"]["name"]) for v in var_asign_list if "name" in v["left"].keys()]

		for v in var_asign_list:
			if "name" in v["left"].keys():

				output.append( {"var_name":v["left"]["name"],  "var_value":normalize_plus_operator(v["right"])})



	#asigns.append(tmp)
	return output



#========================================== Need to Build

def find_all_xhrOpen_arguments(funcBody):

	output = []


	# finding all ExpressionStatements 
	find_expressionStatements = {"type":"ExpressionStatement"}
	find_callExpression = {"type":"CallExpression"}


	expr_statement_list = extract_partial_from_nested_dict(funcBody, find_expressionStatements)

	for ex in expr_statement_list:
		if "expression" in ex.keys() and ex["expression"]["type"] == "CallExpression"  and "callee" in ex["expression"].keys() and ex["expression"]["callee"]["type"]=="MemberExpression" and "object" in ex["expression"]["callee"].keys() and "name" in ex["expression"]["callee"]["object"].keys():
			if "name" in ex["expression"]["callee"]["property"].keys() and ex["expression"]["callee"]["property"]["name"] == "open":
				
				#in case which we find xhr.open

				xhr_var_name = ex["expression"]["callee"]["object"]["name"]
				args = ex["expression"]["arguments"]
				output.append({"xhr_var_name": xhr_var_name, "aruguments_raw":args})


	return output

def normalize_plus_operator(obj):

	output = []

	if obj["type"] == "BinaryExpression" and obj["operator"] == "+" and "left" in obj.keys() and "right" in obj.keys():



		if (obj["right"]["type"] == "Identifier" or obj["right"]["type"] == "Literal") and obj["left"]["type"] == "BinaryExpression" and obj["left"]["operator"] == "+":

			output.extend(normalize_plus_operator(obj["left"]))
			output.append({"type":obj["right"]["type"],  "name":obj["right"][list(obj["right"].keys())[1]]})


		elif (obj["right"]["type"] == "Identifier" or obj["right"]["type"] == "Literal") and (obj["left"]["type"] == "Identifier" or obj["left"]["type"] == "Literal"):

			output.append({"type":obj["left"]["type"],  "name":obj["left"][list(obj["left"].keys())[1]]})
			output.append({"type":obj["right"]["type"],  "name":obj["right"][list(obj["right"].keys())[1]]})


		elif (obj["right"]["type"] == "Identifier" or obj["right"]["type"] == "Literal") and not obj["left"]["type"] == "BinaryExpression":

			output.append({"type":obj["left"]["type"],  "name": obj["left"] })
			output.append({"type":obj["right"]["type"],  "name":obj["right"][list(obj["left"].keys())[1]]})



		elif (not obj["right"]["type"] == "Identifier" and not obj["right"]["type"] == "Literal") and obj["left"]["type"] == "BinaryExpression" and obj["left"]["operator"] == "+":

			output.extend(normalize_plus_operator(obj["left"]))
			output.append({"type":obj["left"]["type"],  "name":obj["right"] })



		else:
			output.append({"type":obj["left"]["type"],  "name": obj["left"]})
			output.append({"type":obj["right"]["type"],  "name": obj["right"]})



		return output



	else:

		output.append(obj)

		return output

def find_vlue_of_variable(funcBody , varName):
	pass


#========================================== Need to Build



js_file = "./all_js_samples/js_sample0.js"
js_raw = read_js_file_content(js_file)
all_parsed = convert_nodeObjects_to_dict(js_parser(js_raw))

write_to_file("./parsed_all.txt", str(js_parser(js_raw)))

search0 = {"type":"FunctionDeclaration"}
function_list = extract_partial_from_nested_dict(all_parsed, search0)



for func in function_list:

	for x in find_all_xhrOpen_arguments(func) :
		if len(x)>0:
			print("\n\n______________ function: " + func["id"]["name"] )	
			print("\n______________ all assignments in function: ")
			[print(b) for b in find_all_assignments_in_function_body(func)]
			print("\n______________ xhr variables:")
			print(find_all_xhr_variable_in_function_body(func))
			print("\n"+x['xhr_var_name'] + ".open (\"" + x["aruguments_raw"][0]["value"] + "\", ")		
			[print(z) for z in normalize_plus_operator(x["aruguments_raw"][1])]
			print(","+str(x["aruguments_raw"][2]["value"])+")")
			print("\n")