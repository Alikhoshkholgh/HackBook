
      var api_server = "localhost";
      var curr_table_name = "resources";

      function setup_reportTable_names(tablename_list) {
        /*
        tablename_list.forEach(name => {
          var reportTable_name_holder = document.getElementById("report_table_names_place");
          //reportTable_name_holder.innerHTML += "<div class = \"col-xl-3 col-md-6\" style=\"flex:0 0 10%;\"> <button class = \"btn\" type=\"button\">" + name + "</button> </div>";
          reportTable_name_holder.innerHTML += " <div class = \"col-3\" style=\"flex:0 0 10%; height: 40px;\"> <div class = \"card card-block\" > <button class = \"btn\" type=\"button\">" + name + "</button> </div> </div>";        
        });
        */        
      }

      function parse_reportTableNames(raw_) {
        return raw_.replaceAll("'", "").replaceAll("[", "").replaceAll("]", "").replaceAll("(", "").replaceAll("), ", "").replaceAll(")", "").split(",");
      }

      function get_setup_reportTable_names(targetName) {
        url = "http://" + api_server + ":5000/readtablealltablenames?targetname=" + targetName
        var xhttp1 = new XMLHttpRequest();
        xhttp1.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
            //console.log("raw reportTableName List: " + xhttp1.responseText);
            var reportTable_name_list = parse_reportTableNames(xhttp1.responseText)
            //console.log("reportTableName List: " + reportTable_name_list);
            setup_reportTable_names(reportTable_name_list)
          }
        };
        xhttp1.open("GET", url, true);
        xhttp1.setRequestHeader("Accept", "application/json");
        xhttp1.send();
      }

      function get_show_configurations(targetName) {

        flush_configs()

        url = "http://" + api_server + ":5000/config?targetname=" + targetName
        var xhttp1 = new XMLHttpRequest();
        xhttp1.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
            confs = parse_raw_config_to_json(xhttp1.responseText);
            for (const key in confs) {
              if (confs.hasOwnProperty(key)) {
                //console.log(`configurations: ${key} : ${confs[key]}`)
                put_config_to_ui(key, confs[key])
              }
            }
          }
        };
        xhttp1.open("GET", url, true);
        xhttp1.setRequestHeader("Accept", "application/json");
        xhttp1.send();
      }

      function parse_raw_config_to_json(rawConfig) {
        var modif = (rawConfig).replaceAll("[{", "{").replaceAll("}]", "}").replaceAll("'", "\"").replaceAll("False", "\"False\"").replaceAll("True", "\"True\"");
        parsed_j = JSON.parse(modif);
        return parsed_j;
      }

      function put_config_to_ui(conf_title, confi_data) {
        var config_place = document.getElementById("scrap_config_place");
        config_place.innerHTML += " <div class = \"card-body \"><h4>-->" + conf_title + "</h4>     " + confi_data + " </div>";
      }

      function flush_configs(){

        var config_place = document.getElementById("scrap_config_place");
        config_place.innerHTML = "";
      }

      function parse_colNames(clear_str) {
        return clear_str.replaceAll("'", "").replaceAll("[", "").replaceAll("]", "").split(",");
      }

      function parse_tableData(clear_str) {
        var output = [
          ["https://example/a/b/c", "text/html"],
        ];
        var rows = clear_str.replaceAll("[", "").replaceAll("]", "").split("), ");

        /*
        rows.forEach(row => {
          cols_ = row.split(",");
          cols = []
          cols_.forEach(col => {
            item = col.replaceAll("(", "").replaceAll("'", "");
            cols.push(item);
          });
          output.push(cols);
        });

        */
        return output
      }

      function fix_tableHeaders(col_names, table_id) {
        let table = document.getElementById(table_id);
        let thead = document.createElement('thead');
        let tr_header_row = document.createElement('tr');
        table.appendChild(thead);
        /*
        col_names.forEach(col => {
          let th = document.createElement('th');
          th.textContent = col;
          tr_header_row.appendChild(th);
        });
        */

        thead.appendChild(tr_header_row);
      }

      function fix_tableData(list_rows, bodyTable_id) {
        let tablebody = document.getElementById(bodyTable_id);
        /*
        list_rows.forEach(row => {
          let tr_per_data_row = document.createElement('tr');
          row.forEach(col => {
            let td = document.createElement('td');
            td.textContent = col;
            tr_per_data_row.appendChild(td);
          });
          tablebody.appendChild(tr_per_data_row);
        });

        */
      }

      function loadTableData(targetName, tableName, table_id, bodyTable_id) {

        flush_report_tables()


        url = "http://" + api_server + ":5000/readtablecolumnnames?targetname=" + targetName + "&table=" + tableName
        url2 = "http://" + api_server + ":5000/readtabledata?targetname=" + targetName + "&table=" + tableName
        // ---------------------- Column names
        var xhttp1 = new XMLHttpRequest();
        xhttp1.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
            col_names = parse_colNames(xhttp1.responseText)
            fix_tableHeaders(col_names, table_id)
          }
        };
        xhttp1.open("GET", url, true);
        xhttp1.setRequestHeader("Accept", "application/json");
        xhttp1.send();
        var xhttp2 = new XMLHttpRequest();
        xhttp2.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
            list_rows = parse_tableData(xhttp2.responseText);
            fix_tableData(list_rows, bodyTable_id);
          }
        };
        xhttp2.open("GET", url2, true);
        xhttp2.setRequestHeader("Accept", "application/json");
        xhttp2.send();
      }

      function flush_report_tables(){

        let tablebody = document.getElementById("report_table_body_1");
        tablebody.innerHTML = ""
      }

      function put_target_list_to_sidebar(target_list) {

        /*
        target_list.forEach(name => {
          name = name.trim();
          if (name != "") {
            var target_elem = " <li class > <button class=\"btn btn-link\"> <span class = \"pcoded-mtext\" onclick=\"target_list_sidebar_click(\'"+name+"\')\">" + name + "</span> <span class = \"pcoded-badge label label-info \">exmpl</span> </button> </li>";
            var target_list_place = document.getElementById("target_list_sidebar_place");
            target_list_place.innerHTML += target_elem
          }
        });

        */
      }

      function get_show_target_list_sidebar() {
        url = "http://" + api_server + ":5000/targetlist"
        var xhttp1 = new XMLHttpRequest();
        xhttp1.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
            target_list = parse_colNames(xhttp1.responseText);
            //console.log(`Target list: ${target_list}`);
            put_target_list_to_sidebar(target_list);
          }
        };
        xhttp1.open("GET", url, true);
        xhttp1.setRequestHeader("Accept", "application/json");
        xhttp1.send();
      }

      function target_list_sidebar_click(targetName){        
        change_targetName_in_ui(targetName);
        get_show_configurations(targetName);
        get_setup_reportTable_names(targetName);
        loadTableData(targetName, curr_table_name, "report_table_main1", "report_table_body_1");
        //get_show_operation_state(targetName)
        get_show_progress(targetName)

        get_show_treemap(targetName)
      }

      function change_targetName_in_ui(targetName){
        var targe_name_place = document.getElementById("target_name_place");
        targe_name_place.innerHTML = targetName;
      }

      function start_attack(){


        var targetName_ = document.getElementById("target_name_place");
        targetName = targetName_.innerHTML;


        //alert("attacking on : " + targetName);

        url = "http://" + api_server + ":5000/intruptprocess?targetname=" + targetName + "&changeto=started"
        var xhttp1 = new XMLHttpRequest();
        xhttp1.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {

            var resp = xhttp1.responseText;
            alert(resp);

          }
        };
        xhttp1.open("post", url, true);
        xhttp1.setRequestHeader("Accept", "application/json");
        xhttp1.send();
      }

      function get_show_progress(targetName){
              
        //alert(`'${content_items_count}', '${average_response_time}', '${firewall_detected_us************}', '${tried_requests}', '${buffer_items_count}', '${count_found_pages}', '${immediate_alerts**********}'`)

        var content_items_count = "noValue";
        var average_response_time = "noValue";
        var firewall_detected_us = "noValue";
        var tried_requests = "noValue";
        var buffer_items_count = "noValue";
        var count_found_pages = "noValue";
        var immediate_alerts = "noValue";

        var operation_state_id = document.getElementById("Operation_state_id");
        var content_items_count_id = document.getElementById("content_items_count_id");
        var average_response_time_id = document.getElementById("average_response_time_id");
        var tried_requests_id = document.getElementById("tried_requests_id");
        var buffer_items_count_id = document.getElementById("buffer_items_count_id");
        var count_found_pages_id = document.getElementById("count_found_pages_id");
        
        //var immediate_alerts_id = document.getElementById("");
        //var firewall_detected_us_id = document.getElementById("");


        url = "http://" + api_server + ":5000/progressReport?targetname=" + targetName
        var xhttp1 = new XMLHttpRequest();
        xhttp1.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {

            var resp = xhttp1.responseText;

            var progress_values = JSON.parse(resp);

            content_items_count_id.innerHTML = progress_values["queue_items_count"];
            average_response_time_id.innerHTML = progress_values["average_response_time"];
            tried_requests_id.innerHTML = progress_values["tried_requests"];
            buffer_items_count_id.innerHTML = progress_values["buffer_items_count"];
            count_found_pages_id.innerHTML = progress_values["count_found_pages"];
            operation_state_id.innerHTML = progress_values["operation_state"];

            //alert(`progress_values : ${JSON.stringify(progress_values)}`);

          }
        };
        xhttp1.open("get", url, true);
        xhttp1.setRequestHeader("Accept", "application/json");
        xhttp1.send();
      }