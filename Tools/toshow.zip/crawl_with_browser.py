from selenium.webdriver.common.by import By
import urllib.request
from selenium.webdriver.common.keys import Keys
from time import sleep
import sys
import os
from selenium import webdriver
from selenium.webdriver.chrome.service import Service

from webdriver_manager.chrome import ChromeDriverManager



'''
driver = webdriver.Firefox()
#driver = webdriver.Chrome()
    
while not self.finish:            
        
	sleep(0.5)
        
	driver = webdriver.Firefox() if driver==None else driver
        
    browser_request_results = []
            
    try:
            
    	##################################################################################################################################### browser_request
            
        driver.get(url)  
        for request in driver.requests:
            if request.response:                        
            	elem = {'url': request.url, 
                		'status': str(request.response.status_code),
                        'headers': str(request.response.headers['content-type']).split(";")[0], 
                        #'body':str(request.response.body),
                        'body': request.response.body,
                        }       

        #print(f"__________________________________ subrequest:  url:{elem['url']},  status:{elem['status']},  content-type:{request.response.headers['content-type']}, body-len{len(elem['body'])}")                               
                
        ##################################################################################################################################### browser_request
                
                
	except Exception as e:
                #print(f"\n\n______________Error__________________________ in BrowserRequestHandler.run() Error Happend: {e}\n\n")
                driver.quit() 
                sleep(0.5)
                driver = None
                
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                ad = ("ErrorType: "+str(exc_type)+"  in File: "+str(fname)+" Line:"+str(exc_tb.tb_lineno))                
                print(f"\n\n______________Error__________________________ in BrowserRequestHandler.run() {e} {ad}")
                
                continue           

    

driver.quit()     
'''




''' Chrome HeadLess
options = Options()
options.headless = True
options.add_argument("--window-size=1920,1200")
'''


'''Create Red border on element
javaScript = "document.querySelectorAll('a').forEach(e => e.style.border='red 2px solid')"
driver.execute_script(javaScript)
'''



'''Disable loading Images and executing js

chrome_options = webdriver.ChromeOptions()
chrome_prefs = {
    "profile.default_content_setting_values": {
        "images": 2,
        "javascript": 2,
    }
}
chrome_options.experimental_options["prefs"] = chrome_prefs

'''



def open_multiple_urls_in_browser(wdriver, url_list):

    try:
    	#wdriver.maximize_window()
        print("\n______________________ open_multiple_urls_in_browser starts....")

        for i,url in enumerate(url_list):

            print(f"quering url: {url}")
            tab_tag = f"tab{i}"

            #wdriver.get(target_url)
            wdriver.execute_script(f"window.open('about:blank', '{tab_tag}')")
            wdriver._switch_to.window(tab_tag)
            wdriver.get(url)
            #print(wdriver.current_url)

        return driver

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        ad = ("ErrorType: "+str(exc_type)+"  in File: "+str(fname)+" Line:"+str(exc_tb.tb_lineno))    
        print(f"\n\n______________Error_in_open_multiple_urls_in_browser()________________________ {e} {ad}")
        return None
        
def find_all_evented_elements(wdriver, debug=False):
    '''
    selenium.webdriver.remote.webelement.WebElement (session="334e70a64572b914ca9b62ac245d154b", element="677388A7F4272C0673508F7ABCC8375B_element_16")>
        accessible_name
        aria_role
        clear
        click
        find_element
        find_elements
        get_attribute
        get_dom_attribute
        get_property
        id
        is_displayed
        is_enabled
        is_selected
        location
        location_once_scrolled_into_view
        parent
        rect
        screenshot
        screenshot_as_base64
        screenshot_as_png
        send_keys
        shadow_root
        size
        submit
        tag_name
        text
        value_of_css_property
    '''
    evented_element_list = []
    elm_count = 0
    elm_obj_list = []

    try:
        #print(f"\n___________________________________ http-get: {url}")
        #driver.get(url)  
        #sleep(10)
        #driver._switch_to.window(tab_tag)

        elm_obj_list = wdriver.execute_script("return document.getElementsByTagName('*')")

        elm_count = len(elm_obj_list)

        #print(f"\n_____________________________________________ all elements len:  {elm_count}")


    except Exception as e:
        #driver.quit() 
        #sleep(0.5)
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        ad = ("ErrorType: "+str(exc_type)+"  in File: "+str(fname)+" Line:"+str(exc_tb.tb_lineno))    
        print(f"\n\n______________Error_in_find_all_evented_elements()________________________ {e} {ad}")
        return None
        



    for i,v in enumerate(elm_obj_list):

        try:
            r_obj = wdriver.execute_cdp_cmd("Runtime.evaluate", {"expression": f"document.getElementsByTagName('*')[{i}]"})    
            lstn = wdriver.execute_cdp_cmd("DOMDebugger.getEventListeners", {"objectId": r_obj['result']['objectId']})

            if not lstn == {'listeners': []}:
                
                if debug:
                    print(f"\n\n____________ tag_name:  {(v.tag_name)}")
                    print(f"\n____________ text:  {(v.text)}")
                    print(f"\n____________ location:  {(v.location)}")
                    print(f"\n____________ runtim-evaluate:  {r_obj}")
                    print(f"\n_______________________________ element-listener:  {lstn}")
                    print(f"\n____________ get_attribute-id:  {(v.get_attribute('id'))}")
                    print(f"\n____________ get_attribute-class:  {(v.get_attribute('class'))}")
                    print("\n==================================================================================================================")
                    #print(f"\n____________ element:  {v}")
                    #print(f"\n____________ dir(v):  {dir(v)}")
                    #print(f"\n____________ get_property:  {(v.get_property())}")
                    #print(f"\n____________ get_dom_attribute:  {(v.get_dom_attribute())}")
                    #print(f"\n____________ value_of_css_property:  {(v.value_of_css_property)}")


                target_elem = {
                    'main-element':v, 
                    'tagname': v.tag_name, 
                    'text':v.text, 
                    'location': v.location, 
                    'runtim-evaluate': r_obj, 
                    'listener': lstn, 
                    'id-attr': v.get_attribute('id'), 
                    'class-attr':v.get_attribute('class'),
                    }

                evented_element_list.append(target_elem)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            ad = ("ErrorType: "+str(exc_type)+"  in File: "+str(fname)+" Line:"+str(exc_tb.tb_lineno))    
            #print(f"\n\n______________Error_in_find_all_evented_elements()________________________ {e} {ad}")

            if "no such element: No node with given id found" in str(e):
                print(f"______________Error_in find_all_evented_elements() ________________________ processing one of elements got an error: no such element")
            elif "stale element reference: stale element not found" in str(e):
                print(f"______________Error_in find_all_evented_elements() ________________________ processing one of elements got an error: stale element not found")
            else:
                print(f"______________Error_in find_all_evented_elements() ________________________ processing one of elements got an error: {e}")
            
            continue
   
    return evented_element_list

def get_all_elements(wdriver):
    try:	
        #wdriver._switch_to.window(tab_identifier)
        elm_obj_list = wdriver.execute_script("return document.getElementsByTagName('*')")
        #print(f"_____________________ get_all_elements return by : {len(elm_obj_list)}")
        return elm_obj_list
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        ad = ("ErrorType: "+str(exc_type)+"  in File: "+str(fname)+" Line:"+str(exc_tb.tb_lineno))    
        print(f"\n\n______________Error_in_get_all_elements()________________________ {e} {ad}")
        return None
    
def extract_links(wdriver):
    
    output = []

    target_tag_list = [
                {'tagName':'a'      , 'sourceKeyWord':['href']},
                #{'tagName':'embed'  , 'sourceKeyWord':['src']},
                #{'tagName':'track'  , 'sourceKeyWord':['src']},
                #{'tagName':'script' , 'sourceKeyWord':['src']},
                #{'tagName':'audio'  , 'sourceKeyWord':['src']},
                #{'tagName':'area'   , 'sourceKeyWord':['href']},
                #{'tagName':'base'   , 'sourceKeyWord':['href']},
                #{'tagName':'link'   , 'sourceKeyWord':['href']},
                #{'tagName':'del'    , 'sourceKeyWord':['cite']},
                #{'tagName':'ins'    , 'sourceKeyWord':['cite']},
                #{'tagName':'q'      , 'sourceKeyWord':['cite']},
                #{'tagName':'command', 'sourceKeyWord':['icon']},
                #{'tagName':'head'   , 'sourceKeyWord':['profile']},
                #{'tagName':'blockquote', 'sourceKeyWord':['cite']},
                #{'tagName':'applet' , 'sourceKeyWord':['codebase']},
                #{'tagName':'html'   , 'sourceKeyWord':['manifest']},
                #{'tagName':'body'   , 'sourceKeyWord':['background']},
                #{'tagName':'input'  , 'sourceKeyWord':['formaction']},
                #{'tagName':'button' , 'sourceKeyWord':['formaction']},
                #{'tagName':'source' , 'sourceKeyWord':['src', 'srcset']},
                #{'tagName':'meta'   , 'sourceKeyWord':['poster', 'src']},
                #{'tagName':'input'  , 'sourceKeyWord':['src', 'usemap']},
                #{'tagName':'iframe' , 'sourceKeyWord':['longdesc', 'src']},
                #{'tagName':'meta'   , 'sourceKeyWord':['content', 'http-equiv']}, #   <meta http-equiv="refresh" content="1;url=https://DomainName/page" /> 
                #{'tagName':'form'   , 'sourceKeyWord':['action', 'longdesc', 'src']},
                #{'tagName':'img'    , 'sourceKeyWord':['longdesc', 'src', 'usemap', 'srcset']},
                #{'tagName':'object' , 'sourceKeyWord':['classid', 'codebase', 'data', 'usemap', 'archive']},
                ]

    tags_only = [x['tagName'] for x in target_tag_list]

    try:

        #wdriver._switch_to.window(tab_identifier)

        all_elem = get_all_elements(wdriver, tab_identifier)

        if not all_elem:
            return []

        ev_elements = [x["main-element"] for x in find_all_evented_elements(wdriver, tab_identifier)]

        all_elem = list(filter( lambda x: x not in ev_elements , all_elem))

        for e in all_elem:
            if not e.tag_name.lower() in tags_only:
                continue
            for t in target_tag_list:
                if t==e.tag_name.lower():

                    print(f"\n>>>>>>>>>>>>>>>>>>> Extract Link. found tag:  {e.tag_name.lower()}")

                    for srctag in target_tag_list[t]:
                        found_url = e.get_attribute(srctag)
                        if not found_url==None and not found_url=='': 
                            output.append(found_url)

        print(f"\n____________________________________ Extract Links, returned len: {len(output)}")

        return output

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        ad = ("ErrorType: "+str(exc_type)+"  in File: "+str(fname)+" Line:"+str(exc_tb.tb_lineno))    
        print(f"\n\n______________Error_in extract_links()________________________ {e} {ad}")
        return []

#not impelemented
def set_proxy_for_browser(wdriver):

    PROXY = "<IP>:port" # IP:PORT or HOST:PORT
    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_argument('--proxy-server=%s' % PROXY)
    chrome = webdriver.Chrome(options=chrome_options)





#=============================================================================================================== main body
establish_delay = 5

target_url = [
                #'https://time.ir',
                #'https://digikala.com',
                'https://khadamat.mardom.ir',
                'https://cinematicket.org',
                'https://digiato.com',
				'https://www.emofid.com',
				'https://ernyka.com',
				'https://learn.pseez.ir',
				'https://srb.iau.ir',
			]


try:

    options = webdriver.ChromeOptions()
    options.add_argument('--ignore-certificate-errors')
    options.add_argument('--ignore-ssl-errors')
    #driver = webdriver.Chrome(ChromeDriverManager().install(), options=options)
    #driver = webdriver.Chrome()
    driver = webdriver.Chrome(options=options)

    for i,url in enumerate(target_url):

        #print(f"quering url: {url}")

        tab_tag = f"tab{i}"

        driver.execute_script(f"window.open('about:blank', '{tab_tag}')")
        driver._switch_to.window(tab_tag)

        
        driver.get(url)
        #print(driver.current_url)
        print(f"\n\n________________________ at {driver.current_url}")
        print("waiting for elements to be completely Established.....")
        sleep(establish_delay)


        ev_elements = find_all_evented_elements(driver)

        all_elements = get_all_elements(driver)

        #link_list = extract_links(driver)

        print(f"--------------------------------- all elements found: #{len(all_elements)}")
        #if not link_list == None and not link_list == [] :
        #    #print(f"--------------------------------- links found: #{len(link_list)}")
        print(f"--------------------------------- evented elements found: #{len(ev_elements)}")


    input("\n\n_________________________________________ press Enter to quit....")


except Exception as e:
    exc_type, exc_obj, exc_tb = sys.exc_info()
    fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
    ad = ("ErrorType: "+str(exc_type)+"  in File: "+str(fname)+" Line:"+str(exc_tb.tb_lineno))    
    print(f"\n\n______________Error_in_main________________________ {e} {ad}")
    
