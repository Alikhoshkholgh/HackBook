
#=================================================================================================================================================== Intercept
from seleniumwire import webdriver


options = webdriver.ChromeOptions()
options.add_argument('--ignore-certificate-errors')
options.add_argument('--ignore-ssl-errors')
#options.add_argument('--allow-running-insecure-content')
driver = webdriver.Chrome(options=options)


abort_all = False


#url = 'https://digikala.com'
url = 'https://cinematicket.org'
'''
'https://digikala.com',
'https://khadamat.mardom.ir',
'https://cinematicket.org',
'https://digiato.com',
'https://www.emofid.com',
'https://ernyka.com',
'https://learn.pseez.ir',
'https://srb.iau.ir',
'''


def my_request_interceptor(request):
    print(f"Intercepted request: {request.method} - {request.url}")
    #if request.path.endswith(('.png', '.jpg', 'jpeg', '.gif')):
    #    print(f"------------------- aborted - Intercepted request: {request.method} - {request.url}")
    #    request.abort()

    #if abort_all:
    #    print(f"------------------- aborted - Intercepted request: {request.method} - {request.url}")
    #    request.abort()


def my_response_interceptor(request, response):
    #print(f"path: {request.url}  stat:{response.status_code}")
    pass


def abort_all():
    global abort_all
    abort_all = True



def no_abort_all():
    global abort_all
    abort_all = False




driver.request_interceptor = my_request_interceptor
driver.response_interceptor = my_response_interceptor

driver.get(url)

input(f"---------------------------------------------- Enter to quit......")

'''
while True:

    ans = input("\n_____________________________ yes to abort")

    if ans.lower() == "y" or ans.lower() == "yes":
        abort_all()

    elif ans.lower() == "n" or ans.lower() == "no":
        no_abort_all()
'''



driver.quit()



#=================================================================================================================================================== Block Requests
'''
from seleniumwire import webdriver
from selenium.webdriver.common.by import By
from seleniumwire import request


# Set up Chrome driver options
options = webdriver.ChromeOptions()


# Create an instance of the Chrome driver
driver = webdriver.Chrome(options=options)


# Define a request interceptor function
def request_interceptor(request):
    # Block image assets
    if request.path.endswith(('.png', '.jpg', '.gif')):
        request.abort()


# Set the request interceptor
driver.request_interceptor = request_interceptor


# Hit the target site
driver.get('https://lambdatest.com')


# Find and print the body content
body = driver.find_element(By.TAG_NAME, 'body')
print(body.text)


# Quit the driver
driver.quit()
'''