
'''
    selenium.webdriver.remote.webelement.WebElement (session="334e70a64572b914ca9b62ac245d154b", element="677388A7F4272C0673508F7ABCC8375B_element_16")>
        accessible_name
        aria_role
        clear
        click
        find_element
        find_elements
        get_attribute
        get_dom_attribute
        get_property
        id
        is_displayed
        is_enabled
        is_selected
        location
        location_once_scrolled_into_view
        parent
        rect
        screenshot
        screenshot_as_base64
        screenshot_as_png
        send_keys
        shadow_root
        size
        submit
        tag_name
        text
        value_of_css_property
'''



############## Target_Mofid


from seleniumwire import webdriver
#from selenium import webdriver
from time import sleep
import sys
import os
#import chromedriver_binary

driver = webdriver.Chrome()
        

#url = "https://emofid.com"
#url = "https://digikala.com"
url = "http://localhost:9001/page12.html"


evented_element_list = []


try:
    print(f"\n___________________________________ http-get: {url}")
    driver.get(url)  
    sleep(7)

    elm_count = 0
    elm_obj_list = driver.execute_script("return document.getElementsByTagName('*')")

    elm_count = len(elm_obj_list)

    #elm_count = driver.execute_script("return document.getElementsByTagName('*').length")
    print(f"\n\n_____________________________________________ all elements len:  {elm_count}")


    for i,v in enumerate(elm_obj_list):

        r_obj = driver.execute_cdp_cmd("Runtime.evaluate", {"expression": f"document.getElementsByTagName('*')[{i}]"})    
        lstn = driver.execute_cdp_cmd("DOMDebugger.getEventListeners", {"objectId": r_obj['result']['objectId']})

        if not lstn == {'listeners': []}:
            
            print(f"\n\n____________ tag_name:  {(v.tag_name)}")
            print(f"\n____________ text:  {(v.text)}")
            print(f"\n____________ location:  {(v.location)}")
            print(f"\n____________ runtim-evaluate:  {r_obj}")
            print(f"\n_______________________________ element-listener:  {lstn}")
            print(f"\n____________ get_attribute-id:  {(v.get_attribute('id'))}")
            print(f"\n____________ get_attribute-class:  {(v.get_attribute('class'))}")
            print("\n==================================================================================================================")

            #print(f"\n____________ element:  {v}")
            #print(f"\n____________ dir(v):  {dir(v)}")
            #print(f"\n____________ get_property:  {(v.get_property())}")
            #print(f"\n____________ get_dom_attribute:  {(v.get_dom_attribute())}")
            #print(f"\n____________ value_of_css_property:  {(v.value_of_css_property)}")

            my_elem = {
                'main-element':v, 
                'tagname': v.tag_name, 
                'text':v.text, 
                'location': v.location, 
                'runtim-evaluate': r_obj, 
                'listener': lstn, 
                'id-attr': v.get_attribute('id'), 
                'class-attr':v.get_attribute('class'),
                }

            evented_element_list.append(my_elem)





    ans = input("do you want to click on any Element? ->")

    if ans.lower() == 'y' or ans.lower() == 'yes':

        elem_sig = input("_____________________ insert your specification for the target element: ->")

        key_ = elem_sig.split(":")[0]
        value_ = elem_sig.split(":")[1]


        found = list(filter(lambda x: key_ in x.keys() and x[key_]==value_ , evented_element_list))[0]

        print("\n\n_____________________ i found this element: ")
        print(found)

        final_ans = input("\n>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> insert yes if you want to proceed: ")

        if final_ans.lower()=="yse" or final_ans.lower()=="y":

            found['main-element'].click()



    input("\n\n__________________________________press Enter to exit....")
    driver.quit() 





except Exception as e:

    #print(f"\n\n______________Error__________________________ in BrowserRequestHandler.run() Error Happend: {e}\n\n")
    driver.quit() 
    sleep(0.5)
    driver = None
    exc_type, exc_obj, exc_tb = sys.exc_info()
    fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
    ad = ("ErrorType: "+str(exc_type)+"  in File: "+str(fname)+" Line:"+str(exc_tb.tb_lineno))    
    print(f"\n\n______________Error__________________________ {e} {ad}")
    
